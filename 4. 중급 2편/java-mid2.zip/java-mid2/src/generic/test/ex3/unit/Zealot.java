package generic.test.ex3.unit;

public class Zealot extends BioUnit {

    public Zealot(String name, int hp) {
        super(name, hp);
    }
}
