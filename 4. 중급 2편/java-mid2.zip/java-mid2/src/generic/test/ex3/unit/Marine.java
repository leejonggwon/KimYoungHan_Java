package generic.test.ex3.unit;

public class Marine extends BioUnit {

    public Marine(String name, int hp) {
        super(name, hp);
    }
}
