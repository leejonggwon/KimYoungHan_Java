package generic.test.ex3.unit;

public class Zergling extends BioUnit {

    public Zergling(String name, int hp) {
        super(name, hp);
    }
}
