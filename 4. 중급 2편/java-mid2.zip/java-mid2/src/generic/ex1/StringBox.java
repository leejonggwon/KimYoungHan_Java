package generic.ex1;

public class StringBox {

    private String value;

    public void set(String object) {
        this.value = object;
    }

    public String get() {
        return value;
    }
}
