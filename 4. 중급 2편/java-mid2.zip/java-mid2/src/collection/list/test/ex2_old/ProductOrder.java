package collection.list.test.ex2_old;

public class ProductOrder {
    String productName;
    int price;
    int quantity;
}