package collection.deque.test.queue;

public interface Task {
    void execute();
}