package nested.test;

public class OuterClass1 {

    static class NestedClass {
        public void hello() {
            System.out.println("NestedClass.hello");
        }
    }
}
