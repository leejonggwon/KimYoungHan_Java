package nested.test;

public interface Hello {
    void hello();
}
