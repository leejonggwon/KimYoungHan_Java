package nested.test;

public class OuterClass2 {

    class InnerClass {
        public void hello() {
            System.out.println("InnerClass.hello");
        }
    }
}
