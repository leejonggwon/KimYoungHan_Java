package nested.anonymous.ex;

public interface Process {
    void run();
}
