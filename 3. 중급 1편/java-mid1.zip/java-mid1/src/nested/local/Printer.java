package nested.local;

public interface Printer {
    void print();
}
