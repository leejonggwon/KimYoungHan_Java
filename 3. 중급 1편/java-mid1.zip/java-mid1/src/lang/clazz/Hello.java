package lang.clazz;

public class Hello {
    public String hello() {
        return "hello!";
    }
}
