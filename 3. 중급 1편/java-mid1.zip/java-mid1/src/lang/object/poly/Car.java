package lang.object.poly;

public class Car {
    public void move() {
        System.out.println("자동차 이동");
    }
}
