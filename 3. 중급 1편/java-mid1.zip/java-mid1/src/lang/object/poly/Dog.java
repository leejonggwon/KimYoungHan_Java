package lang.object.poly;

public class Dog {
    public void sound() {
        System.out.println("멍멍");
    }
}
