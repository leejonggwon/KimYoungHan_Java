package lang.string.test;

public class TestString3 {

    public static void main(String[] args) {
        String str = "hello.txt";
        int index = str.indexOf(".txt");
        System.out.println("index = " + index);
    }
}
