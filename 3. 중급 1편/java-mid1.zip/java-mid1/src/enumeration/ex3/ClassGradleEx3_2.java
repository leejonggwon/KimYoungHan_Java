package enumeration.ex3;

public class ClassGradleEx3_2 {

    public static void main(String[] args) {
        int price = 10000;

        DiscountService discountService = new DiscountService();

/*
        Grade grade = new Grade(); //enum 생성 불가
        int result = discountService.discount(grade, price);
        System.out.println("result price: " + result);
*/
    }
}
